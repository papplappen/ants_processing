import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class ants_0_1 extends PApplet {


PrintWriter output;
int counter;

final int ANT_COLOR = 0xff000000;
final int HOME_COLOR = 0xff775c0a;
final int FOOD_COLOR = 0xff2eb217;
final int SIGNAL_POS_COLOR = 0xff7251cc;
final int SIGNAL_NEG_COLOR = 0xfff70e35;

ArrayList<Signal>[][] signals;
ArrayList<Signal>[][] signalsTBR;

ArrayList<Food> foods = new ArrayList<Food>();
ArrayList<Food> foodsTBR = new ArrayList<Food>();

ArrayList<Ant> ants = new ArrayList<Ant>();
ArrayList<Ant> antsTBR = new ArrayList<Ant>();

Home home;

int NUMBER_ANTS = 500;

boolean paused = true;
boolean show_signals = false;
boolean show_all = true;
public void setup() {
  //size(1280, 720);
  
  frameRate(1000);
  ellipseMode(RADIUS);
  fill(0);
  textAlign(LEFT, TOP);
  textSize(30);


  output = createWriter("ants.csv"); 


  signals = new ArrayList[PApplet.parseInt(width/Ant.VIEW_CONE_RADIUS)+1][PApplet.parseInt(height/Ant.VIEW_CONE_RADIUS)+1];
  signalsTBR = new ArrayList[signals.length][signals[0].length];
  for (int i = 0; i < signals.length; i++) {
    for (int j = 0; j < signals[0].length; j++) {
      signals[i][j] = new ArrayList<Signal>();
      signalsTBR[i][j] = new ArrayList<Signal>();
    }
  }

  home = new Home(new PVector(width/2, height/2), 50);
  for (int i = 0; i < NUMBER_ANTS; i++) {
    home.newAnt();
  }
}
public void draw() {
  background(0xcc);

  if (!paused) {
    updateAll();

    if (foods.size() < 8) {
      foods.add(new Food(new PVector(random(0, width), random(0, height)), PApplet.parseInt(random(50, 100))));
    }
    counter ++;
    if (counter >= 100) {
      counter = 0;
      output.println(ants.size());
      // output.flush();
    }
    if (ants.size() <= 0) {
      output.flush();
      output.close();
      exit();
    }
  }
  if (show_all) {
    showAll();
  }
  text(ants.size(), 0, 0);
  text(frameRate, 0, 25);
}

public void updateAll() {
  for (int i = 0; i < signals.length; i++) {
    for (int j = 0; j < signals[0].length; j++) {
      for (Signal s : signals[i][j]) {
        s.update();
      }
      signals[i][j].removeAll(signalsTBR[i][j]);
    }
  }

  for (Ant a : ants) {
    a.update();
  }
  ants.removeAll(antsTBR);

  foods.removeAll(foodsTBR);

  home.update();
}
public void showAll() {
  if (show_signals) {
    for (int i = 0; i < signals.length; i++) {
      for (int j = 0; j < signals[0].length; j++) {
        for (Signal s : signals[i][j]) {
          s.show();
        }
      }
    }
  }

  for (Food f : foods) {
    f.show();
  }

  for (Ant a : ants) {
    a.show();
  }

  home.show();
}

public void mousePressed() {
  if (mouseButton == LEFT) {
    addNewSignal(new Signal(new PVector(mouseX, mouseY), 100));
  } else if (mouseButton == RIGHT) {
    addNewSignal(new Signal(new PVector(mouseX, mouseY), -100));
  } else if (mouseButton == CENTER) {
    foods.add(new Food(new PVector(mouseX, mouseY), 200));
  }
}

public void keyPressed() {
  if (key == ' ') {
    paused = !paused;
  } else if (key == 's') {
    show_signals = !show_signals;
  } else if (key == ESC) {
    output.flush();
    output.close();
    exit();
  } else if ( key == 'a') {
    show_all = !show_all;
  }
}


public void addNewSignal(Signal s) {
  signals[signalsIndex(s.pos.x)][signalsIndex(s.pos.y)].add(s);
}

public int signalsIndex(float p) {
  return PApplet.parseInt(p/Ant.VIEW_CONE_RADIUS);
}
class Ant {
  PVector pos;
  PVector dir;

  final float SPEED = 3;
  static final float VIEW_CONE_RADIUS = 100;
  final float VIEW_CONE_ANGLE = radians(45);
  final float VIEW_CONE_SLICE = cos(VIEW_CONE_ANGLE);
  final float RANDOM_ROTATE_MAX = radians(30);
  final float RANDOM_ROTATE_MIN = radians(15);

  int counter = 0;
  final int STEPS_BETWEEN_SIGNAL = PApplet.parseInt(75/SPEED);

  float mood = 0;
  final float FEAR_MOOD = -0.25f;
  final float FOOD_MOOD = 1;
  final float DELIVERY_MOOD = 1;

  float life;
  final float LIFE_DRAIN = 0.001f;
  final float LIFE_PANIC = 0.1f;



  boolean carries_food = false;

  Ant(PVector pos_, PVector dir_) {
    pos = pos_;
    dir = dir_;
    life = random(0.75f, 1);
  }

  public void update() {

    PVector tempDir = new PVector();

    if (!carries_food) {
      for (Food f : foods) {
        PVector relativePos = PVector.sub(f.pos, pos);
        if (relativePos.mag() < f.RADIUS) {
          f.take(1);
          carries_food = true;
          mood += FOOD_MOOD;
          dir.mult(-1);
          f.take(1-life);
          life = 1;
        }
        if (inViewCone(relativePos)) {
          tempDir.set(relativePos);
        }
      }
    }

    {
      PVector relativePos = PVector.sub(home.pos, pos);
      if (relativePos.mag() < home.radius) {
        if (carries_food) {
          carries_food = false;
          mood += DELIVERY_MOOD;
          home.food += 1;
          //dir.mult(-1);
          dir = PVector.random2D();
        }
        if (home.take_food(1-life)) {
          life=1;
        }
      }
      if (carries_food && inViewCone(relativePos)) {
        tempDir.set(relativePos);
      }
    }

    if (tempDir.magSq() == 0) {
      for (int i = -1; i <= 1; i++) {
        for (int j = -1; j <= 1; j++) {
          int x = signalsIndex(pos.x)+i;
          int y = signalsIndex(pos.y)+j;
          if (x >= 0 && x< signals.length && y >= 0 && y < signals[0].length) {
            for (Signal s : signals[x][y]) {
              PVector relativePos = PVector.sub(s.pos, pos);
              if (inViewCone(relativePos)) {
                float dist = relativePos.mag();
                float dot = PVector.dot(relativePos, dir)/dist;
                relativePos.mult((s.intensity*((dot-VIEW_CONE_SLICE)/(1-VIEW_CONE_SLICE)))/max(VIEW_CONE_RADIUS/2, VIEW_CONE_RADIUS-dist));
                tempDir.add(relativePos);
              }
            }
          }
        }
      }
    }


    if (tempDir.magSq() != 0) {
      dir.add(tempDir);
      dir.normalize();
    }
    {
      float r = max(RANDOM_ROTATE_MIN, (1-life)*RANDOM_ROTATE_MAX);
      dir.rotate(random(-r, r));
    }
    //if (inViewCone(new PVector(mouseX, mouseY).sub(pos))) {
    //  dir.mult(-1);
    //  mood += FEAR_MOOD;
    //}

    pos.add(PVector.mult(dir, SPEED));

    if (pos.x > width) {
      pos.x = width;
      dir.x = - dir.x;
    }
    if (pos.x < 0) {
      pos.x = 0;
      dir.x = - dir.x;
    }    
    if (pos.y > height) {
      pos.y = height;
      dir.y = - dir.y;
    }    
    if (pos.y < 0) {
      pos.y = 0;
      dir.y = - dir.y;
    }

    mood *= 0.99f;

    counter++;
    if (counter >= STEPS_BETWEEN_SIGNAL) {
      counter = 0;
      if (abs(mood) > 0.01f) {
        addNewSignal(new Signal(pos.copy(), mood));
      }
    }

    life -= LIFE_DRAIN;
    if (mood >= 0 && life < LIFE_PANIC) {
      mood = FEAR_MOOD;
    } else if (life <= 0) {
      antsTBR.add(this);
    }
  }

  public boolean inViewCone(PVector p_rel) {
    float dist = p_rel.mag();
    float dot = PVector.dot(p_rel, dir)/dist;
    return dist < VIEW_CONE_RADIUS && dot > VIEW_CONE_SLICE;
  }

  public void show() {
    pushStyle();
    noStroke();
    //if (mood > 0) {
    //  fill(0, 20*mood, 0);
    //} else {
    //  fill(20*mood, 0, 0);
    //}
    fill(ANT_COLOR);
    circle(pos.x-5*dir.x, pos.y-5*dir.y, 3);
    circle(pos.x, pos.y, 2);

    if (carries_food) {
      fill(FOOD_COLOR);
    } else {
      fill(ANT_COLOR);
    }
    circle(pos.x+5*dir.x, pos.y+5*dir.y, 2.5f);

    PVector o = new PVector(dir.y, -dir.x);
    
    stroke(ANT_COLOR);
    line(pos.x + 5*(o.x+dir.x), pos.y + 5*(o.y+dir.y), pos.x - 5*(o.x+dir.x), pos.y - 5*(o.y+dir.y));
    line(pos.x + 5*(-o.x+dir.x), pos.y + 5*(-o.y+dir.y), pos.x - 5*(-o.x+dir.x), pos.y - 5*(-o.y+dir.y));
    line(pos.x + 5*(o.x), pos.y + 5*(o.y), pos.x - 5*(o.x), pos.y - 5*(o.y));

    popStyle();
  }
}

class Food {
  PVector pos;
  float capacity;
  float INIT_CAPACITY;
  final float RADIUS = 25;

  Food(PVector pos_, int capacity_) {
    pos = pos_;
    capacity = capacity_;
    INIT_CAPACITY = capacity_;
  }

  public void take(float f) {
    capacity -= f;
    if (capacity <= 0) {
      foodsTBR.add(this);
    }
  }

  public void show() {
    pushStyle();
    noStroke();
    fill(FOOD_COLOR, 128);
    circle(pos.x, pos.y, RADIUS);
    fill(FOOD_COLOR);
    circle(pos.x, pos.y, capacity/INIT_CAPACITY * RADIUS);
    popStyle();
  }
}

class Home {
  PVector pos;
  float radius;

  float food = 0;

  int counter = 0;
  final int BIRTH_RATE = 10;
  final float NEW_ANT_COST = 3;
  final float NEW_ANT_MINIM = 20;

  Home(PVector pos_, float radius_) {
    pos = pos_;
    radius = radius_;
  }


  public void update() {
    counter++;
    if (food > NEW_ANT_MINIM && counter >= BIRTH_RATE) {
      counter = 0;
      newAnt();
      food -= NEW_ANT_COST;
    }
  }

  public void newAnt() {
    ants.add(new Ant(pos.copy(), PVector.random2D()));
  }

  public boolean take_food(float f) {
    if (food == 0) { 
      return false;
    }
    food -= f;
    if (food <= 0) {
      food = 0;
    }
    return true;
  }


  public void show() {
    pushStyle();

    fill(HOME_COLOR);
    circle(pos.x, pos.y, radius);
    
    noStroke();
    fill(FOOD_COLOR);
    circle(pos.x, pos.y, 0.9f*min(1, food/NEW_ANT_MINIM) * radius);


    popStyle();
  }
}
class Signal {
  PVector pos;
  float intensity;
  float INIT_INTENSITY;

  Signal(PVector pos_, float intensity_) {
    pos = pos_;
    intensity = intensity_;
    INIT_INTENSITY = abs(intensity_);
  }

  public void update() {
    intensity *= 0.99f;
    if (abs(intensity) < 0.1f*INIT_INTENSITY) {
      signalsTBR[signalsIndex(pos.x)][signalsIndex(pos.y)].add(this);
    }
  }
  public void show() {
    pushStyle();
    noStroke();
    if (intensity < 0) {
      fill(SIGNAL_NEG_COLOR, abs(intensity)*255);
    } else {
      fill(SIGNAL_POS_COLOR, abs(intensity)*255);
    }
    circle(pos.x, pos.y, 4);
    popStyle();
  }
}
  public void settings() {  size(1600, 900); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "ants_0_1" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
